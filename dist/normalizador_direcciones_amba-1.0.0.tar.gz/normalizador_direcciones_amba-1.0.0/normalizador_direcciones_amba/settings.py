# coding: UTF-8

## Tipo de normalizacion
CALLE = 0
CALLE_ALTURA = 1
CALLE_Y_CALLE = 2
INVALIDO = -1

CALLEJERO_AMBA_SERVER = 'http://10.10.5.53/callejero_amba/'

## Tipo de Match
NO_MATCH = 0
MATCH = 1
MATCH_INCLUIDO = 2
MATCH_PERMUTADO = 3
MATCH_EXACTO = 4