# coding: UTF-8

## Tipo de normalizacion
CALLE = 0
CALLE_ALTURA = 1
CALLE_Y_CALLE = 2
INVALIDO = -1

CALLEJERO_GBA_SERVER = 'http://epok.lemur-django.usig.gcba.gov.ar:8000/'

## Tipo de Match
NO_MATCH = 0
MATCH = 1
MATCH_INCLUIDO = 2
MATCH_PERMUTADO = 3
MATCH_EXACTO = 4